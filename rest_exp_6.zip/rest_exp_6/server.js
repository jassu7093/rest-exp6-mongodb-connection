// server.js
// Connect Node.js to MongoDB using Mongoose

const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');

dotenv.config(); // load .env variables
const app = express();
app.use(express.json());

// ------------------ CONNECT TO MONGODB ------------------
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ MongoDB connected successfully!');
  } catch (error) {
    console.error('❌ MongoDB connection failed:', error.message);
    process.exit(1);
  }
};
connectDB();

// ------------------ TEST ROUTE ------------------
app.get('/', (req, res) => {
  res.send('MongoDB Connection Successful 🚀');
});

// ------------------ START SERVER ------------------
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
